import Foundation

struct GameModel {
    var targetNumbers: [Int]
    var currentLevel: Int
    var timeLimit: Int
}
